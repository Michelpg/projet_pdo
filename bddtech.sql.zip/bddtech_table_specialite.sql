
-- --------------------------------------------------------

--
-- Structure de la table `specialite`
--

DROP TABLE IF EXISTS `specialite`;
CREATE TABLE IF NOT EXISTS `specialite` (
  `idspec` int(11) NOT NULL,
  `designations` varchar(40) NOT NULL,
  PRIMARY KEY (`idspec`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `specialite`
--

INSERT INTO `specialite` (`idspec`, `designations`) VALUES
(1, 'DEV APP'),
(2, 'ING RESEAUX'),
(3, 'INTEG BDD'),
(4, 'ADM SYS'),
(5, 'Chef de projets');
