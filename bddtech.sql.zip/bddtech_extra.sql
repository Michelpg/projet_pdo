
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `candidat`
--
ALTER TABLE `candidat`
  ADD CONSTRAINT `candidat_ibfk_1` FOREIGN KEY (`idspec`) REFERENCES `specialite` (`idspec`);

--
-- Contraintes pour la table `resultat`
--
ALTER TABLE `resultat`
  ADD CONSTRAINT `resultat_ibfk_1` FOREIGN KEY (`idCand`) REFERENCES `candidat` (`idCand`),
  ADD CONSTRAINT `resultat_ibfk_2` FOREIGN KEY (`idEpr`) REFERENCES `epreuve` (`idEpr`);
