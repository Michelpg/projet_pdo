
-- --------------------------------------------------------

--
-- Structure de la table `epreuve`
--

DROP TABLE IF EXISTS `epreuve`;
CREATE TABLE IF NOT EXISTS `epreuve` (
  `idEpr` int(11) NOT NULL,
  `designation` varchar(35) NOT NULL,
  `Coef` int(11) NOT NULL,
  `Note_eliminat` int(11) NOT NULL,
  PRIMARY KEY (`idEpr`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `epreuve`
--

INSERT INTO `epreuve` (`idEpr`, `designation`, `Coef`, `Note_eliminat`) VALUES
(1, 'Informatique', 5, 3),
(2, 'Français', 3, 2),
(3, 'Anglais', 2, 2),
(4, 'Culture Générale', 2, 2),
(5, 'Physique', 3, 3),
(6, 'Mathématiques', 3, 3);
