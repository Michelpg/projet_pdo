
-- --------------------------------------------------------

--
-- Structure de la table `candidat`
--

DROP TABLE IF EXISTS `candidat`;
CREATE TABLE IF NOT EXISTS `candidat` (
  `idCand` int(11) NOT NULL,
  `nom` varchar(35) NOT NULL,
  `Prenoms` varchar(35) NOT NULL,
  `Adresse` varchar(100) NOT NULL,
  `courriel` varchar(50) NOT NULL,
  `idspec` int(11) NOT NULL,
  PRIMARY KEY (`idCand`),
  KEY `idspec` (`idspec`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `candidat`
--

INSERT INTO `candidat` (`idCand`, `nom`, `Prenoms`, `Adresse`, `courriel`, `idspec`) VALUES
(1010, 'RIVAY', 'Claude', '24 rue de Montreuil 75020', 'no_adr1@info.sup', 1),
(1020, 'DUBOIS', 'Clément', '10 Bd. Voltaire 75011', 'no_adr2@info.sup', 2),
(1030, 'LAVERDURE', 'Patrick', '74 rue Daumesnil 75008', 'no_adr3@info.sup', 3),
(1155, 'RATTIER', 'Claude', '44 rue de Montreuil 75020', 'no_adr10@info.sup', 1),
(1212, 'Edme', 'Liza', '12 rue de Montreuil 75020', 'no_adr13@info.sup', 1),
(1941, 'Hazem', 'Karim', '13 Av. Gl De Gaule 94000', 'no_adr15@info.sup', 4),
(2109, 'LEE', 'Yan Fu', '113 Av. Gl De Gaule 92000', 'no_adr14@info.sup', 4),
(3325, 'Tripon', 'Arnaud', '51 rue de Montreuil 75020', 'no_adr12@info.sup', 5),
(5000, 'VERIN', 'Eric', '10-Bis rue Saint Maur 75012', 'no_adr4@info.sup', 3),
(5500, 'LEROY', 'Axelle', '11 Av. Gl De Gaule 77000', 'no_adr5@info.sup', 1),
(6500, 'FISCHER', 'Vincent', '15 rue de la Pierre Levée 75011', 'no_adr6@info.sup', 4),
(7070, 'CORNU', 'Isabelle', '76 rue de Montreuil 75020', 'no_adr7@info.sup', 5),
(7090, 'CORNU', 'Isabelle', '1 Av. de la République 75011', 'no_adr9@info.sup', 4),
(7150, 'BORIS', 'Jean', '25 Av. Parmentier 75011', 'no_adr8@info.sup', 2),
(9801, 'GRANDVALLET', 'lucas', '33 rue du Maroc 75020', 'no_adr11@info.sup', 3);
